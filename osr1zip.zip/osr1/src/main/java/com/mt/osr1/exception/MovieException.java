package com.mt.osr1.exception;

public class MovieException extends Exception {

	MovieException()
	{
		super();
	}
	
	public MovieException(String s)
	{
		System.out.println(s);
	}
	
}
